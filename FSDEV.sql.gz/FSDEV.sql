-- Adminer 4.8.1 MySQL 5.7.39 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `fs_authors`;
CREATE TABLE `fs_authors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fs_authors` (`id`, `author_name`) VALUES
(1,	'Шляпа П.П.'),
(2,	'Злючкин Е.Г.'),
(3,	'Шубкина Василина'),
(4,	'Березкин Вова'),
(5,	'Перцев'),
(10,	'Новосёлкин'),
(14,	'Штрудель К.К.');

DROP TABLE IF EXISTS `fs_books`;
CREATE TABLE `fs_books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `book_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `book_author` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `book_author` (`book_author`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fs_books` (`id`, `book_name`, `book_author`) VALUES
(9,	'Неполезная книженция по сайтам',	5),
(26,	'Заброшенные базы данных ',	3),
(38,	'Дурацкая верстка сайтов',	10),
(39,	'Javascript для кипятильников',	14),
(40,	'CSS для кофейников',	4),
(41,	'HTML для чайников',	3),
(43,	'Идиотская верстка таблицами для адаптивов',	1),
(50,	'SQL Ужасы',	14),
(51,	'Гламурная верстка',	3),
(52,	'Веб-дизайн для продвинутых',	3),
(53,	'Вредные советы по JS',	1),
(55,	'Веб глазами кота',	14);

-- 2024-01-26 11:53:24
